import {Component, Input, OnInit} from '@angular/core';

@Component({
  selector: 'app-even',
  templateUrl: './even.component.html',
  styleUrls: ['./even.component.css']
})
export class EvenComponent implements OnInit {
  @Input() evenNumber!: {number: number};

  constructor() {  
    console.log(`Constructor`);  
}  
  
ngOnChanges() {  
  console.log(`ngOnChanges`);  
}  

ngOnInit() {  
    console.log(`ngOnInit`);  
}  

ngDoCheck() {  
    console.log("ngDoCheck")  
}  

ngAfterContentInit() {  
    console.log("ngAfterContentInit");  
}  

ngAfterContentChecked() {  
    console.log("ngAfterContentChecked");  
}  

ngAfterViewInit() {  
    console.log("ngAfterViewInit");  
}  

ngAfterViewChecked() {  
    console.log("ngAfterViewChecked");  
}  

ngOnDestroy() {  
    console.log("ngOnDestroy");  
}  
  
}

