export interface Person {
    id: number;
    name: string;
    gender?: string;
  }
  
  export const Persons: Person[] = [
    { id: 1, name: 'Aakash', gender: 'Male'},
    { id: 2, name: 'Roopal', gender: 'Female' },
    { id: 3, name: 'Krupali', gender: 'Female' },
    { id: 4, name: 'Jay',gender: 'Male'}
  ];
  